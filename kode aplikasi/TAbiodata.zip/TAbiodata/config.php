<?php 
	define('DB_HOST', 'mysql.idhostinger.com');
	define('DB_USER', 'u370382181_217');
	define('DB_PASS', 'vicitesis');
	define('DB_NAME', 'u370382181_217');

 ?>