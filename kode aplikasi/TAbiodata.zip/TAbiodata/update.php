	<?php 
 require_once 'koneksi.php';

 if($_SERVER['REQUEST_METHOD'] == 'POST')
 {
 	$id = $_POST['id'];
 	$no_identitas = $_POST['no_identitas'];
 	$nama_pasien = $_POST['nama_pasien'];
 	$jen_kel = $_POST['jen_kel'];
 	$tempat = $_POST['tempat'];
 	$tgl_lahir = $_POST['tgl_lahir'];
 	$alamat = $_POST['alamat'];
 	$no_hp = $_POST['no_hp'];
 	$tinggi_badan = $_POST['tinggi_badan'];
 	$berat_badan = $_POST['berat_badan'];
 	$jenis = $_POST['jenis'];

 	$query = "UPDATE  tb_pasien SET no_identitas = '$no_identitas', nama_pasien = '$nama_pasien', tempat = '$tempat', tgl_lahir = '$tgl_lahir', alamat = '$alamat', no_hp = '$no_hp', tinggi_badan = '$tinggi_badan', berat_badan = '$berat_badan' WHERE id='$id'";

 	$exeQuery = mysqli_query($konek, $query); 

 	echo ($exeQuery) ? json_encode(array('kode' =>1, 'pesan' => 'data berhasil update')) :  json_encode(array('kode' =>2, 'pesan' => 'data gagal diupdate'));
 }
 else
 {
 	 echo json_encode(array('kode' =>101, 'pesan' => 'request tidak valid'));
 }

 ?>