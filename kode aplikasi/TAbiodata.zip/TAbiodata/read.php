<?php 
require_once 'koneksi.php'; 
$query = "SELECT * FROM tb_pasien ORDER BY nama_pasien";
$result = mysqli_query($konek,$query);
$array = array();
while ($row  = mysqli_fetch_assoc($result))
{
	$array[] = $row; 
}
echo ($result) ? 
json_encode(array("kode" => 1, "result"=>$array)) :
json_encode(array("kode" => 0, "pesan"=>"data tidak ditemukan"));

// require_once 'koneksi.php'; 
// $query = "SELECT * FROM tb_biodata ORDER BY nama";
// $result = mysqli_query($konek,$query);
// $responsistem["result"] = array();
// if(mysqli_num_rows($result) > 0){
// 	while ($row  = mysqli_fetch_assoc($result))
// 	{
// 		$responsistem["kode"] = "1";
// 		$data['id'] = $row['id']; 
// 		$data['nama'] = $row['nama']; 
// 		$data['usia'] = $row['usia']; 
// 		$data['domisili'] = $row['domisili']; 
// 		$data['gambar'] = $row['gambar']; 
// 		array_push($responsistem["result"],$data);
// 	}
// }else{
// 	$responsistem["kode"] = "0";
// 	$responsistem["pesan"] = "data tidak ditemukan";
// }
// echo json_encode($responsistem);
?>