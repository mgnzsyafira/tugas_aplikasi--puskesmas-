<?php 
 require_once 'koneksi.php';

 if($_SERVER['REQUEST_METHOD'] == 'POST')
 {
 	$no_identitas = $_POST['no_identitas'];
 	$nama_pasien = $_POST['nama_pasien'];
 	$jen_kel = $_POST['jen_kel'];
 	$tempat = $_POST['tempat'];
 	$tgl_lahir = $_POST['tgl_lahir'];
 	$alamat = $_POST['alamat'];
 	$no_hp = $_POST['no_hp'];
 	$tinggi_badan = $_POST['tinggi_badan'];
 	$berat_badan = $_POST['berat_badan'];
 	$jenis = $_POST['jenis'];

 	$query = "INSERT INTO tb_pasien (no_identitas, nama_pasien, jen_kel, tempat, tgl_lahir, alamat, no_hp, tinggi_badan, berat_badan, jenis) VALUES ('$no_identitas','$nama_pasien','$jen_kel','$tempat','$tgl_lahir','$alamat','$no_hp','$tinggi_badan','$berat_badan','$jenis')";

 	$exeQuery = mysqli_query($konek, $query); 

 	echo ($exeQuery) ? json_encode(array('kode' =>1, 'pesan' => 'berhasil menambahkan data')) :  json_encode(array('kode' =>2, 'pesan' => 'data gagal ditambahkan'));
 }
 else
 {
 	 echo json_encode(array('kode' =>101, 'pesan' => 'request tidak valid'));
 }

 ?>